/***** Arthur Chenu *****/

#ifndef MENU_H
#define MENU_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <graph.h>

void menu(void);

#endif