<h2><?= $titre ?></h2>
<br>
<p>Bienvenue sur Sondage.com !</p>
<p>Ce site vous permet de créer vos propres sondages et de les partager avec vos amis ! </p>
<br>
<div class="container">
	<img src="<?php echo base_url(); ?>assets/images/sondage" alt="Avatar" class="image">
	<div class="overlay">
		<div class="text">N'hésitez pas et <a href="utilisateurs/inscription">inscrivez-vous</a> dès maintenant !</div>
	</div>
</div>