		</div>
		<script>
		CKEDITOR.replace( 'editor1' );
		</script>
		<br>
		<br>
		<footer>
			<nav id="bottom" class="navbar navbar-expand-lg navbar-dark bg-dark">

				<div class="collapse navbar-collapse navbarColor02">
					<ul class="navbar-nav mr-auto">
						<li><h5>© Maxime Blanchon & Arthur Chenu, mis à jour en Juin 2018.</h5></li>
					</ul>

					<ul class="navbar-nav navbar-right">
						<li><a class="nav-link" href="#top">Haut de la page</a></li>
					</ul>
					<ul class="navbar-nav navbar-right">
						<li><a class="nav-link" href="mailto:maximeblanchon91490@gmail.com">Contact</a></li>
					</ul>
				</div>

			</nav>
		</footer>
	</body>
	</html>