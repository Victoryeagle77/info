<h2><?php echo $sondage['titre']; ?></h2>
<br>


<small class="post-date"><strong>Créé le <?php echo $sondage['created_at']; ?> par <?php echo $createur->pseudo; ?></strong></small><br>
<div class="post-description">
	<div class="just">
		<?php echo $sondage['description']; ?>
	</div>
</div>
<br>
<?php if(($this->session->userdata('id_utilisateur')) == ($sondage['id_utilisateur'])): ?>
<p class="text-warning">/!\ Partagez votre sondage en envoyant ce lien aux participants : <a href=" <?php echo base_url().'sondages/'.$sondage['hash_titre']; ?>"> <?php echo base_url().'sondages/'.$sondage['hash_titre']; ?></a> !</p>
<p class="text-warning">/!\ Pour clore ce sondage, cliquez sur "Modifier" et cochez la case "Clore le sondage".</p>
<br>
<?php endif; ?>
<p class="text-info">Lieu : <?php echo $sondage['lieu']; ?><br> Créneaux horaires proposées :  <br> le <?php echo $sondage['date1']; ?> à <?php echo substr($sondage['heure1'], 0, 5); ?><br>
	
	<?php if(!($sondage['date2'])==NULL&&(!($sondage['heure2'])==NULL)): ?> le <?php echo $sondage['date2']; ?> à <?php echo substr($sondage['heure2'], 0, 5); ?><br><?php endif; ?>
	<?php if(!($sondage['date3'])==NULL&&(!($sondage['heure3'])==NULL)): ?> le <?php echo $sondage['date3']; ?> à <?php echo substr($sondage['heure3'], 0, 5); ?><?php endif; ?></p>

	<?php if(($this->session->userdata('id_utilisateur')) == ($sondage['id_utilisateur'])): ?>
	<hr>
	<h2>Gestionnaire de sondages</h2>
	<br>

<div class="btn-group" role="group" aria-label="Basic example">

		<?php if($sondage['closed_survey'] == 'on') : ?>
			<?php echo form_open('/sondages/results/'.$sondage['hash_titre']); ?>
			<input type="submit" value="Résultats" class="btn btn-success">
			</form>
		<?php endif; ?>

		<?php echo form_open('/sondages/edit/'.$sondage['hash_titre']); ?>
		<input type="submit" value="Modifier" class="btn btn-info">
		</form>
		<?php echo form_open('/sondages/delete/'.$sondage['ids']); ?>
		<input type="submit" value="Supprimer" class="btn btn-danger">
		</form>
		</div>
<?php endif; ?>

<hr>

<?php if($this->session->userdata('est_co')) : ?>

	<h2 id="participants"> Participations </h2>
	<br>
	<?php if($reponses) : ?>

		<?php foreach ($reponses as $reponse) : ?>

			<?php $heure_rep = explode(" ", $reponse['created_at']);?>
			<?php $creneau = explode(" ", $reponse['creneau']);?>

			<div class="card text-white bg-secondary mb-3">
				<div class="card-header">	
					<p><strong><?php echo $reponse['pseudo']; ?></strong> a participé au sondage le <?php echo $heure_rep[0]; ?> à <?php echo substr($heure_rep[1], 0, 5); ?></p>
				</div>
				<div class="card-body">
					<p class="align-left"><strong>Créneaux horaire choisi :</strong> le <?php echo $creneau[0]; ?> à <?php echo  substr($creneau[1], 0, 5); ?></p>
					<?php if($reponse['description'] != '') : ?>
						<p  class="align-left"><strong>Réponse :</strong> <?php echo $reponse['description']; ?></p>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
		<?php else : ?>
			<p>Personne n'a participé à ce sondage pour l'instant.</p>
		<?php endif; ?>
		<hr>


		<?php if(!($sondage['closed_survey'] == 'on')) : ?>
			<?php if(($this->session->userdata('id_utilisateur')) != ($sondage['id_utilisateur'])): ?>

			<?php echo validation_errors(); ?>
			<?php echo form_open('reponses/create/'.$sondage['ids']); ?>
			<h2 id="rep">Répondre</h2>
			<br>
			<?php if(($nbrep->test)<1): ?>
				<div class="form-group">
					<label>Choississez une des dates proposées par <?php echo $createur->pseudo; ?></label>
					<select class="custom-select" name="creneau">
						<option value="<?php echo $sondage['date1']; ?> <?php echo substr($sondage['heure1'], 0, 5); ?>">le <?php echo $sondage['date1']; ?> à <?php echo substr($sondage['heure1'], 0, 5); ?></option>
						<?php if(!($sondage['date2'])==NULL&&(!($sondage['heure2'])==NULL)): ?> 
						<option value="<?php echo $sondage['date2']; ?> <?php echo substr($sondage['heure2'], 0, 5); ?>">
							le <?php echo $sondage['date2']; ?> à <?php echo substr($sondage['heure2'], 0, 5); ?>
						</option>
					<?php endif; ?>
					<?php if(!($sondage['date3'])==NULL&&(!($sondage['heure3'])==NULL)): ?> 
					<option value="<?php echo $sondage['date3']; ?> <?php echo substr($sondage['heure3'], 0, 5); ?>">le <?php echo $sondage['date3']; ?> à <?php echo substr($sondage['heure3'], 0, 5); ?></option>			
				<?php endif; ?>
			</select>
		</div>

		<div class="form-group">
			<label>Ajoutez un message (facultatif)</label>
			<textarea rows="6" cols="50" class="form-control" name="description" placeholder="Ajoutez une description"></textarea>
		</div>

		<input type="hidden" name="hash_titre" value="<?php echo $sondage['hash_titre']; ?>">
		<button class="btn btn-primary" type="submit">Submit</button>
	</form>

	<?php else : ?>
		<p>Vous avez déjà participé à ce sondage.</p>
	<?php endif; ?>

<?php endif; ?>
<?php else : ?>
	<p class="text-danger">[x] Le sondage a été cloturé. Vous ne pouvez donc plus y participer.</p>

<?php endif; ?>

<?php else : ?>

	<?php if($sondage['closed_survey'] == 'on') : ?>
		<p class="text-danger">[x] Le sondage a été cloturé. Vous ne pouvez donc plus y participer.</p>
		<p><a href="<?php echo base_url(); ?>/utilisateurs/connexion">Connectez-vous</a> ou <a href="<?php echo base_url(); ?>/utilisateurs/inscription">inscrivez-vous</a> pour répondre à ce sondage et voir les commentaires.</p>
		<?php else: ?>
			<p><a href="<?php echo base_url(); ?>/utilisateurs/connexion">Connectez-vous</a> ou <a href="<?php echo base_url(); ?>/utilisateurs/inscription">inscrivez-vous</a> pour répondre à ce sondage et voir les commentaires.</p>
		<?php endif; ?>
	<?php endif; ?>
