<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['sondages/index'] = 'sondages/index';
$route['sondages/create'] = 'sondages/create';
$route['sondages/update'] = 'sondages/update';
$route['sondages/(:any)'] = 'sondages/view/$1';
$route['sondages'] = 'sondages/index';
$route['default_controller'] = 'pages/view';
$route['(:any)'] = 'pages/view/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
