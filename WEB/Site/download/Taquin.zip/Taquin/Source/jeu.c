//Arthur Chenu

#include <graph.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "jeu.h"
#include "menu.h"


int Def_Boutton(int x, int y, int L, int H){ /*Fonction qui permet de définir l'aspect 
graphique d'un bouton en fonction de la position 
en abscisse, en ordonnée, de la hauteur et de la largeur*/
  couleur c = CouleurParComposante(180, 180, 180); /*Fonction de la librairie graphique
  permettant de définir une couleur par coloration tri_chromique de pixel rouge vert bleu
  (en l'occurence du gris-beige) */
  ChoisirCouleurDessin(c); //Attribu à l'objet précisé la variable couleur c définie
  RemplirRectangle(x, y, L, H);
}

int choix(char *path_img, int height, int width){ /*Fonction qui permet de définir 
une image avec sa hauteur et sa largeur, réutilisable dans le programme*/ 
	ChargerImage(path_img, 0, 0, 0, 0, height, width);
}

int pose(int x, int y, int* case_h, int* case_v){ /*Fonction qui définie le nombre de cases 
à disposer en colonnes et en lignes selon les coordonnées de clic de souris*/
	if ((x>=100) && (x<=140) && (y>=180) && (y<=220))
		*case_h=3;
	else if ((x>=220) && (x<=280) && (y>=200) && (y<=250))
		*case_h=4;
	else if ((x>=360) && (x<=410) && (y>=200) && (y<=250))
		*case_h=5;
	else if ((x>=640) && (x<=680) && (y>=190) && (y<=230))
		*case_h=6;
	else if ((x>=760) && (x<=810) && (y>=200) && (y<=240))
		*case_h=7;
	else if ((x>=870) && (x<=920) && (y>=200) && (y<=250))
		*case_h=8;
	EffacerEcran(0); /*Permet d'effacer, de rafraichir ce qui est à 
	l'écran et le rend noir avec la couleur 0*/
	ChargerImageFond("../images/menu.jpg");
	Nbcolonnes(); 
	waiting();
	x=_X;
	y=_Y;
	if ((x>=100) && (x<=140) && (y>=180) && (y<=220))
		*case_v=3;
	else if ((x>=220) && (x<=280) && (y>=200) && (y<=250))
		*case_v=4;
	else if ((x>=360) && (x<=410) && (y>=200) && (y<=250))
		*case_v=5;
	else if ((x>=640) && (x<=680) && (y>=190) && (y<=230))
		*case_v=6;
	else if ((x>=760) && (x<=810) && (y>=200) && (y<=240))
		*case_v=7;
	else if ((x>=870) && (x<=920) && (y>=200) && (y<=250))
		*case_v=8;
}

int calcul(char* path_img, unsigned int case_h, unsigned int case_v){ /*Fonction qui va permettre selon le chemin d'accés
	et le nombre de cases horizontales et verticales, d'effectuer 
	le jeu en découpant l'image en cases et en mélangant celles-ci aléatoirement*/
	int height=500, width=500; // résolution
	int l,h; //Futures coordonnées d'une image choisie pour son découpage et son mélange aléatoire 
	int i = 0, j = 0;
	int k, move, aleatoire; /*variable d'indice de déplacement, de déplacement, et de génération aléatoire*/
	int x_Null= 0, y_Null= 0; //Position Nulle respective en abscisse et ordonnée
	int compteur; /*variable que nous voulions utiliser pour le nombre de déplacement,
    le score du joueur mais que nous n'avons finalement pas peu afficher dans le programme*/
	l=height/case_h;
	h=width/case_v;
		for(i = 0; i < case_h; i++){ 
			for(j = 0; j < case_v; j++){ 
				if((i != 0) || (j != 0)) /*Definition de 3 boucles for en fonction 
				de l'incrémentation positive de i et j, afin de découper l'image selon
				ses coordonnées l et h, tant que i et j ne sont pas égales à 0*/
						ChargerImage(path_img, i*(l+10), j*(h+10), i*l, j*h, l, h);
			}
		}	
		for (i = 0; i < 150; ++i){
			int aleatoire=rand()%4+0; /*variable égale à un modulo de la fonction rand 
			pour générer aléatoirement un nombre compris entre 0 et 3 inclus*/
			if (aleatoire==0){ // Si le nombre généré aléatoirement est 0
					if (x_Null< (case_h - 1) * (l+10)){ 
							CopierZone(0, 1, x_Null, y_Null, l, h, 0, 0); /* CopierZone() est une fonction de la librairie -lgraph
							qui permet ici de séléctionner une partie de l'image*/ 
							CopierZone(0, 2, x_Null+ l+10, y_Null, l, h, 500, 500);
							CopierZone(1, 0, 0, 0, l, h, x_Null+l+10, y_Null);
							CopierZone(2, 0, 500, 500, l, h, x_Null, y_Null);
							x_Null= x_Null+ l + 10;
						}			
			}else if (aleatoire==1){ // Si le nombre généré aléatoirement est 1
				if (x_Null> 0){
							CopierZone(0, 1, x_Null, y_Null, l, h, 0, 0);
							CopierZone(0, 2, x_Null- l-10, y_Null, l, h, 500, 500);
							CopierZone(1, 0, 0, 0, l, h, x_Null-l-10, y_Null);
							CopierZone(2, 0, 500, 500, l, h, x_Null, y_Null);
							x_Null= x_Null- l - 10;
						}			
			}else if (aleatoire==2){ // Si le nombre généré aléatoirement est 2
					if (y_Null< (case_v - 1) * (h+10)){
							CopierZone(0, 1, x_Null, y_Null, l, h, 0, 0);
							CopierZone(0, 2, x_Null, y_Null+h+10, l, h, 500, 500);
							CopierZone(1, 0, 0, 0, l, h, x_Null, y_Null+h+10);
							CopierZone(2, 0, 500, 500, l, h, x_Null, y_Null);
							y_Null= y_Null+ h + 10;					
						}			
			}else if (aleatoire==3){ // Si le nombre généré aléatoirement est 3
						if (y_Null> 0){
							CopierZone(0, 1, x_Null, y_Null, l, h, 0, 0);
							CopierZone(0, 2, x_Null, y_Null-h-10, l, h, 500, 500);
							CopierZone(1, 0, 0, 0, l, h, x_Null, y_Null-h-10);
							CopierZone(2, 0, 500, 500, l, h, x_Null, y_Null);
							y_Null= y_Null- h - 10;		
						}				
			}
		}		
		while(1){
			if (ToucheEnAttente()){
				move=Touche(); /*Assigne à la variable move l'action de déplacement
				par les flèches du clavier grâce à la fonction Touche de la librairie lgraph*/
					if (move==(XK_Left)){ /*Déplacement vers la gauche avec l'indice de la librairie
					lgraph ou XK constitue l'indice de déplacement, le sens*/
						if (x_Null< (case_h - 1) * (l+10)){
							CopierZone(0, 1, x_Null, y_Null, l, h, 0, 0);
							CopierZone(0, 2, x_Null+ l+10, y_Null, l, h, 500, 500);
							CopierZone(1, 0, 0, 0, l, h, x_Null+l+10, y_Null);
							CopierZone(2, 0, 500, 500, l, h, x_Null, y_Null);
							x_Null= x_Null+ l + 10;
							compteur ++; //compteur comptant le nombre déplacement vers le haut
						}
					}else if (move==(XK_Right)){ //Déplacement vers la droite
						if (x_Null> 0){
							CopierZone(0, 1, x_Null, y_Null, l, h, 0, 0);
							CopierZone(0, 2, x_Null- l-10, y_Null, l, h, 500, 500);
							CopierZone(1, 0, 0, 0, l, h, x_Null-l-10, y_Null);
							CopierZone(2, 0, 500, 500, l, h, x_Null, y_Null);
							x_Null= x_Null- l - 10;
							compteur ++; //compteur comptant le nombre déplacement vers la droite
						}
					}else if (move==(XK_Up)){ //Déplacement vers la haut
						if (y_Null< (case_v - 1) * (h+10)){
							CopierZone(0, 1, x_Null, y_Null, l, h, 0, 0);
							CopierZone(0, 2, x_Null, y_Null+h+10, l, h, 500, 500);
							CopierZone(1, 0, 0, 0, l, h, x_Null, y_Null+h+10);
							CopierZone(2, 0, 500, 500, l, h, x_Null, y_Null);
							y_Null= y_Null+ h + 10;
							compteur ++; //compteur comptant le nombre déplacement vers le haut
						}
					}else if (move==(XK_Down)){ //Déplacement vers le bas
						if (y_Null> 0){
						CopierZone(0, 1, x_Null, y_Null, l, h, 0, 0);
						CopierZone(0, 2, x_Null, y_Null-h-10, l, h, 500, 500);
						CopierZone(1, 0, 0, 0, l, h, x_Null, y_Null-h-10);
						CopierZone(2, 0, 500, 500, l, h, x_Null, y_Null);
						y_Null= y_Null- h - 10;
						compteur ++; //compteur comptant le nombre déplacement vers le bas
						}
					}
				
			}
		}		
}

