//Arthur Chenu

#include <graph.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "jeu.h"
#include "menu.h"

void main() {
	srand(time(NULL)); /*Dans jeu.c, rand() retourne aléatoirement un nombre 
	aléatoie en fonction de srand initialisée sur le temps écoulé actuel*/
	InitialiserGraphique(); //Fonction de la librairie -lgraph initialisant une fenêtre graphique
	CreerFenetre(100,100,1280,700); /*Fonction de la librairie -lgraph 
	affichant la fenêtre selon les coordonnées saisies*/
	menu();
}
