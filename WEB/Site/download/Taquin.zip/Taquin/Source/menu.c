//Arthur Chenu

#include <graph.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "menu.h"
#include "jeu.h"

void TextColor(){ // Fonction définissant la couleur des textes
  couleur c = CouleurParComposante(50,50,50);
  ChoisirCouleurDessin(c);
}

void waiting(){ /*Fonction permettant de prendre en compte les coordonnées
	de la souris sans effectuer d'action tant que la souris n'est pas cliquée*/
	while(!SourisCliquee());
	int x=_X, y=_Y; //Coordonnées _X et _Y de la souris attribué à des variables
}

void Commencer(){ // Fonction qui définit le bouton Commencer 
  Def_Boutton(13, 380, 120, 35); 
  TextColor();
  EcrireTexte(15, 405, "Commencer", 1); /*Fonction de la librairie lgraph
  permettant d'écrire un text selon des coordonnées*/ 
}

void Nblignes(){
  Def_Boutton(500, 620, 163, 26); // Nombre de lignes à séléctionner affiché graphiquement
  TextColor();
  EcrireTexte(500, 640, "Nombre de lignes", 1); 
  Def_Boutton(110, 200, 30, 26);
  TextColor();
  EcrireTexte(120, 220, "3", 1);
  Def_Boutton(250, 200, 30, 26);
  TextColor();
  EcrireTexte(260, 220, "4", 1);
  Def_Boutton(380, 200, 30, 26);
  TextColor();
  EcrireTexte(390, 220, "5", 1);
  Def_Boutton(640, 200, 30, 26);
  TextColor();
  EcrireTexte(650, 220, "6", 1);
  Def_Boutton(760, 200, 30, 26);
  TextColor();
  EcrireTexte(770, 220, "7", 1);
  Def_Boutton(900, 200, 30, 26);
  TextColor();
  EcrireTexte(910, 220, "8", 1);
}

void Nbcolonnes(){
  Def_Boutton(500, 620, 190, 26); // Nombre de colonnes à séléctionner affiché graphiquement
  TextColor();
  EcrireTexte(500, 640, "Nombre de colonnes", 1);
  Def_Boutton(110, 200, 30, 26);
  TextColor();
  EcrireTexte(120, 220, "3", 1);
  Def_Boutton(250, 200, 30, 26);
  TextColor();
  EcrireTexte(260, 220, "4", 1);
  Def_Boutton(380, 200, 30, 26);
  TextColor();
  EcrireTexte(390, 220, "5", 1);
  Def_Boutton(640, 200, 30, 26);
  TextColor();
  EcrireTexte(650, 220, "6", 1);
  Def_Boutton(760, 200, 30, 26);
  TextColor();
  EcrireTexte(770, 220, "7", 1);
  Def_Boutton(900, 200, 30, 26);
  TextColor();
  EcrireTexte(910, 220, "8", 1);
}

void menu(){
	int width=1280, height=700;
	unsigned int case_h, case_v; //nombre de cases horizontales et verticales
	int x,y;  
	int curseur=SourisCliquee(); /*variable curseur dont la valeur est la fonction
	de la librairie lgraph SourisCliquee() permettant de définir une action 
	à effectuer lorsque la souris est cliquée*/
	SourisPosition();
	x=_X;
	y=_Y; 
	int i = 0, j = 0;
	int l,h;
	char *path_image;	
	ChargerImageFond("../images/menu.jpg"); //Image de fond pour le menu
	Commencer();
	while(1){
	SourisPosition();
		if (_X!=x||_Y!=y){
			x=_X;
			y=_Y;
		}
		curseur=SourisCliquee();
		if (curseur){ 
				if ((x>=10) && (x<=130) && (y>=380) && (y<=420)){ //Séléction pour commencer une partie
					EffacerEcran(0);
					ChargerImage("../images/miniature1.jpg", 100, 50, 0, 0, 270, 270); /*Vignette de la première image*/ 
					ChargerImage("../images/miniature2.jpg", 400, 50, 0, 0, 270, 270); /*Vignette de la deuxième image*/
					ChargerImage("../images/miniature3.jpg", 700, 50, 0, 0, 270, 270); /*Vignette de la troisième image*/	
					if (curseur){
						waiting(); //Enregistrer les positions de la souris mais ne rien faire
						x=_X;
						y=_Y;
						if ((x>=100) && (x<=350) && (y>=110) && (y<=300)){ //Séléction de la première images par coordonnées de la souris
							EffacerEcran(0); //Rafraichir l'écran
							ChargerImageFond("../images/menu.jpg"); //Image de fond lors de la séléction des lignes et des colonnes
							Nblignes();
							if (curseur){
								waiting();
								x=_X;
								y=_Y;
								pose(x,y,&case_h,&case_v);
								EffacerEcran(0);			
								ChargerImage("../images/miniature1.jpg", 850, 150, 0, 0, 400, 400); 
								// Miniature de la première image à reconstituer	
								calcul("../images/rofm1-1.jpg",case_h,case_v); //effectuer la fonction calcul pour la première image								
							}
						}						
						if ((x>=390) && (x<=640) && (y>=100) && (y<=340)){ //Séléction de la seconde images par coordonnées de la souris
						EffacerEcran(0);
						ChargerImageFond("../images/menu.jpg"); //Image de fond lors de la séléction des lignes et des colonnes
						Nblignes();
						if (curseur){
							waiting();
							x=_X;
							y=_Y;
							pose(x,y,&case_h,&case_v);							
							EffacerEcran(0);
							ChargerImage("../images/miniature2.jpg", 850, 150, 0, 0, 400, 400);	
							// Miniature de la seconde image à reconstituer
							calcul("../images/rofm2-2.jpg",case_h,case_v); //effectuer la fonction calcul pour la second image	
						}
					}
					if ((x>=670) && (x<=920) && (y>=110) && (y<=310)){ //Séléction de la troisième images par coordonnées de la souris
						EffacerEcran(0);
						ChargerImageFond("../images/menu.jpg"); //Image de fond lors de la séléction des lignes et des colonnes
						Nblignes();
						if (curseur){
							waiting();
							x=_X;
							y=_Y;
							pose(x,y,&case_h,&case_v);
							EffacerEcran(0);
							ChargerImage("../images/miniature3.jpg", 850, 150, 0, 0, 400, 400);	
							// Miniature de la troisème image à reconstituer
							calcul("../images/rofm3-3.jpg",case_h,case_v); //effectuer la fonction calcul pour la troisième image
						}
					}
				}
			}

		}
	}
}

